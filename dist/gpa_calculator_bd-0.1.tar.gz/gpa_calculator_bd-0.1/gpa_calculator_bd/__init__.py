from .gpa import calculate_gpa
from .cgpa import calculate_cgpa
from .average import calculate_average
